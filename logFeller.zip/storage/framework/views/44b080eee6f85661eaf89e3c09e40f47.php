

<?php $__env->startSection('content'); ?>

                        <div class="row">
                            <!-- View sales -->
                            <div class="col-xl-4 mb-4 col-lg-5 col-12">
                                <div class="card">
                                <div class="d-flex align-items-end row">
                                    <div class="col-7">
                                    <div class="card-body text-nowrap">
                                        <h5 class="card-title mb-0">Congratulations <?php echo e($loggedInUser); ?>! 🎉</h5>
                                        
                                    </div>
                                    </div>
                                    <div class="col-5 text-center text-sm-left">
                                    <div class="card-body pb-0 px-0 px-md-4">
                                        <img src="../../assets/img/illustrations/card-advance-sale.png" height="140" alt="view sales">
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!-- View sales -->

                            <!-- Statistics -->
                            <div class="col-xl-8 mb-4 col-lg-7 col-12">
                                <div class="card h-100">
                                <div class="card-header">
                                    <div class="d-flex justify-content-between mb-3">
                                    <h5 class="card-title mb-0">Statistics</h5>
                                    
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row gy-3">
                                    <div class="col-md-3 col-6">
                                        <div class="d-flex align-items-center">
                                        <div class="badge rounded-pill bg-label-primary me-3 p-2"><i class="ti ti-git-fork ti-sm"></i></div>
                                        <div class="card-info">
                                            <h5 class="mb-0"><?php echo e($totalRecords); ?></h5>
                                            <small>Products</small>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6">
                                        <div class="d-flex align-items-center">
                                        <div class="badge rounded-pill bg-label-info me-3 p-2"><i class="ti ti-check ti-sm"></i></div>
                                        <div class="card-info">
                                            <h5 class="mb-0"><?php echo e($activated); ?></h5>
                                            <small>Active Products</small>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6">
                                        <div class="d-flex align-items-center">
                                        <div class="badge rounded-pill bg-label-danger me-3 p-2"><i class="ti ti-alert-triangle ti-sm"></i></div>
                                        <div class="card-info">
                                            <h5 class="mb-0"><?php echo e($inactivated); ?></h5>
                                            <small>In-active Products</small>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6">
                                        <div class="d-flex align-items-center">
                                        <div class="badge rounded-pill bg-label-success me-3 p-2"><i class="ti ti-clock ti-sm"></i></div>
                                        <div class="card-info">
                                            <h5 class="mb-0"><?php echo e($recentProducts); ?></h5>
                                            <small>Recently added</small>
                                        </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--/ Statistics -->
                            
                        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logFeller\resources\views/dashboard.blade.php ENDPATH**/ ?>