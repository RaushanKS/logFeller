Hey <?php echo e($name); ?>,<br /><br />
<p>There was a request to change your password!</p>
<p>If you did not make this request then please ignore this email.</p>
<p>Otherwise, please click this link to change your password: <a href="<?php echo e($link); ?>" target="_blank">Click</a></p>

<br /><br />Cheers,<br />TheLogFeller Team<?php /**PATH C:\xampp\htdocs\logFeller\resources\views/password-forgot.blade.php ENDPATH**/ ?>