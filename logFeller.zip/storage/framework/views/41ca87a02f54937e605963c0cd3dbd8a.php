Hey<br /><br />You had requested to account verify.<br />Please Click the <a href="<?php echo e($link); ?>"
    target="_blank">Confirm</a> to
account verification. <br /><br />
<br /><br />Cheers,<br />Name:The E-Commerce Team<?php /**PATH C:\xampp\htdocs\logFeller\resources\views/email-verification.blade.php ENDPATH**/ ?>