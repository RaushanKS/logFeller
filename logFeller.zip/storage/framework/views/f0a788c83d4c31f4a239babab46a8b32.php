<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact " dir="ltr"
    data-theme="theme-semi-dark" data-assets-path="../../assets/" data-template="vertical-menu-template-semi-dark">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Dashboard | The Log Feller ! </title>


    <meta name="description" content="The Log Feller" />
    <meta name="keywords" content="the, log, feller">
    <!-- Canonical SEO -->
    <link rel="canonical" href="">


    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/icons/favicon.png')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;ampdisplay=swap"
        rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/fontawesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/tabler-icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/flag-icons.css')); ?>" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/rtl/core.css')); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/rtl/theme-semi-dark.css')); ?>" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/node-waves/node-waves.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/swiper/swiper.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/datatables-select-bs5/select.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/sweetalert2/sweetalert2.css')); ?>" />
    

    <!-- Page CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/cards-advance.css')); ?>" />

    <script>
        var baseUrl = '<?php echo url('/'); ?>';
    </script>

    <!-- Helpers -->
    <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

    <style>
        #orderStatus {
            margin-top: 1rem;
            margin-right: 10px;
            width:29% !important;
            float: right;
        }

        .dt-action-buttons {
            margin-bottom: 10px;
        }

        .toast-container.position-fixed.top-0.end-0.p-2.messageShowAlert {
            z-index: 9999 !important;
        }

        .toast {
            padding: 0px !important;
        }

        .toast-header {
            padding: 5px !important;
        }

        .toast .toast-body {
            padding: 1rem 0.5rem !important;
        }

        .editImg {
            height: 150px;
            margin-top: 20px;
            float: inline-start;
        }

        .img-wrap {
            position: relative;
            display: inline-block;
        }

        .image-container {
            position: relative;
            display: inline-block;
        }

        .image-container .deleteImage {
            position: absolute;
            top: 30px; /* Adjust as needed */
            right: 25px; /* Adjust as needed */
            z-index: 999;
            cursor: pointer;
            color: red; /* Optional: add color to the delete icon */
        }

    </style>

</head>

<body>


    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">







            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">


                <div class="app-brand demo ">
                    <a href="index.html" class="app-brand-link">
                        <span class="app-brand-logo demo">
                            <img src="<?php echo e(asset('assets/img/icons/logo1.jpg')); ?>" alt="auth-login-cover" class="img-fluid my-5 auth-illustration">
                            
                        </span>
                        <span class="app-brand-text demo menu-text fw-bold">The Log Feller</span>
                    </a>

                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
                        <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
                        <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>



                <ul class="menu-inner py-1">
                    <!-- Dashboards -->
                    <?php if(Route::currentRouteName()=='dashboard'): ?>
                            <?php
                            $dashboardAdd = 'active open';
                            ?>
                            <?php else: ?>
                            <?php
                            $dashboardAdd = '';
                            ?>
                            <?php endif; ?>
                    <li class="menu-item <?php echo e($dashboardAdd); ?>">
                        <a href="/dashboard" class="menu-link">
                            <i class="menu-icon tf-icons ti ti-smart-home"></i>
                            <div data-i18n="Dashboards">Dashboard</div>
                            
                        </a>
                        
                    </li>

                    


                    <!-- Apps & Pages -->
                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text" data-i18n="Apps & Pages">Apps &amp; Pages</span>
                    </li>
                    <?php if( Route::currentRouteName()=='products'
                        || Route::currentRouteName()=='products.create'
                        || Route::currentRouteName()=='products.store'
                        || Route::currentRouteName()=='products.edit'
                        || Route::currentRouteName()=='product.update'
                        || Route::currentRouteName()=='coupons'
                        || Route::currentRouteName()=='coupon.create'
                        
                    ): ?>
                    
                    <?php
                    $productsView = 'active open';
                    ?>
                    <?php else: ?>
                    <?php
                    $productsView = '';
                    ?>
                    <?php endif; ?>
                    <li class="menu-item <?php echo e($productsView); ?>">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons ti ti-list"></i>
                            <div data-i18n="Products">Products</div>
                        </a>
                        <ul class="menu-sub">
                            <?php if( Route::currentRouteName()=='products'
                                || Route::currentRouteName()=='products.edit'
                                || Route::currentRouteName()=='product.update'
                                
                            ): ?>
                            
                            <?php
                            $productsShow = 'active open';
                            ?>
                            <?php else: ?>
                            <?php
                            $productsShow = '';
                            ?>
                            <?php endif; ?>

                            <li class="menu-item <?php echo e($productsShow); ?>">
                                <a href="<?php echo e(url('/products')); ?>" class="menu-link">
                                    <div data-i18n="All Products">All Products</div>
                                </a>
                            </li>

                            <?php if( Route::currentRouteName()=='products.create'
                                || Route::currentRouteName()=='products.store'    
                            ): ?>
                            
                            <?php
                            $productsAdd = 'active';
                            ?>
                            <?php else: ?>
                            <?php
                            $productsAdd = '';
                            ?>
                            <?php endif; ?>

                            <li class="menu-item <?php echo e($productsAdd); ?>">
                                <a href="<?php echo e(url('products/create')); ?>" class="menu-link">
                                    <div data-i18n="Add Product">Add Product</div>
                                </a>
                            </li>

                            <?php if( Route::currentRouteName()=='coupon.create'
                                || Route::currentRouteName()=='coupon.store'   
                            ): ?>
                            <?php
                            $couponAdd = 'active';
                            ?>
                            <?php else: ?>
                            <?php
                            $couponAdd = '';
                            ?>
                            <?php endif; ?>

                            <li class="menu-item <?php echo e($couponAdd); ?>">
                                <a href="<?php echo e(url('coupon/create')); ?>" class="menu-link">
                                    <div data-i18n="Discount Coupons">Discount Coupons</div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>



            </aside>
            <!-- / Menu -->



            <!-- Layout container -->
            <div class="layout-page">





                <!-- Navbar -->

                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">

                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0   d-xl-none ">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="ti ti-menu-2 ti-sm"></i>
                        </a>
                    </div>


                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">


                        <!-- Search -->
                        
                        <!-- /Search -->





                        <ul class="navbar-nav flex-row align-items-center ms-auto">

                            

                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);"
                                    data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt
                                            class="h-auto rounded-circle">
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="pages-account-settings-account.html">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt
                                                            class="h-auto rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-medium d-block">John Doe</span>
                                                    <small class="text-muted">Admin</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="pages-profile-user.html">
                                            <i class="ti ti-user-check me-2 ti-sm"></i>
                                            <span class="align-middle">My Profile</span>
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="ti ti-logout me-2 ti-sm"></i>
                                            <span class="align-middle">Log Out</span>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->



                        </ul>
                    </div>


                    



                </nav>

                <!-- / Navbar -->



                <!-- Content wrapper -->
                <div class="content-wrapper">

                    <div class="toast-container position-fixed top-0 end-0 p-2 messageShowAlert">
                        <?php if( Session::has("success") ): ?>

                        <div class="alert alert-success alert-dismissible" role="alert">
                            <?php echo e(Session::get("success")); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <?php if( Session::has("error") ): ?>

                        <div class="alert alert-danger alert-dismissible" role="alert">
                            <?php echo e(Session::get("error")); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>


                        <div class="alert alert-warning alert-dismissible" role="alert">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>

                        <?php endif; ?>

                    </div>

                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">



                        <?php echo $__env->yieldContent('content'); ?>


                    </div>
                    <!-- / Content -->




                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl">
                            <div
                                class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
                                <div>
                                    ©
                                    <script>
                                        document.write(new Date().getFullYear())
                                    </script>, made with ❤️ by <a href="https://www.cyberxinfosystem.com/IT"
                                        target="_blank" class="footer-link text-primary fw-medium">Cyberxinfosystem</a>
                                </div>
                                
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->


                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>



        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>


        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>

    </div>
    <!-- / Layout wrapper -->






    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/node-waves/node-waves.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/hammer/hammer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/i18n/i18n.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/swiper/swiper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/sweetalert2/sweetalert2.js')); ?>"></script>
    


    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>


    <!-- Page JS -->
    <script src="<?php echo e(asset('assets/js/extended-ui-sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tables-datatables-extensions.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    <script>
        function toggleVariantsSection(checkbox) {
            const variantsSection = document.getElementById('variants-section');
            if (checkbox.checked) {
                variantsSection.style.display = 'block';
            } else {
                variantsSection.style.display = 'none';
            }
        }

        function addVariant() {
            const variantsSection = document.getElementById('variants-section');
            const variantDiv = document.createElement('div');
            variantDiv.className = 'row variant';
            variantDiv.innerHTML = `
                <div class="mb-3 col-lg-6 col-xl-6 col-12 mb-0">
                    <label class="col-form-label" for="variant_name">Variant Name</label>
                    <input type="text" name="variant_name[]" class="form-control" placeholder="Variant Name" />
                </div>
                <div class="mb-3 col-lg-6 col-xl-6 col-12 mb-0">
                    <label class="col-form-label" for="variant_price">Variant Price</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text">£</span>
                        <input type="text" name="variant_price[]" class="form-control" placeholder="100" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode &gt;= 48 && event.charCode &lt;= 57" />
                    </div>
                </div>
                <div class="mb-3 col-lg-12 col-xl-12 col-12 mb-0">
                    <button type="button" class="btn btn-danger" onclick="removeVariant(this)">Remove Variant</button>
                </div>
            `;
            variantsSection.appendChild(variantDiv);
        }

        function removeVariant(button) {
            const variantDiv = button.closest('.variant');
            variantDiv.parentNode.removeChild(variantDiv);
        }
    </script>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\logFeller\resources\views/layouts/app.blade.php ENDPATH**/ ?>