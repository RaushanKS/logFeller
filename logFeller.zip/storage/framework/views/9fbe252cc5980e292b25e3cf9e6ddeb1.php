

<?php $__env->startSection('content'); ?>

    <h4 class="py-3 mb-4">
        <span class="text-muted fw-light">Product /</span> Edit Product
    </h4>


    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Edit Product</h5>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(url('product/update')); ?>/<?php echo e($product->id); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label" for="product_name">Product Name</label>
                            <input name="product_name" type="text" class="form-control" value="<?php echo e($product->name); ?>" id="product_name" placeholder="Bag of Logs" />
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="product_price">Product Price</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text">£</span>
                                <input name="product_price" type="text" class="form-control" value="<?php echo e($product->sale_price); ?>" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode &gt;= 48 && event.charCode &lt;= 57" placeholder="100" />
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="form-label" for="product_image">Product Image(s)</label>
                            <div class="input-group">
                                <label class="input-group-text" for="product_image">Upload</label>
                                <input name="product_image[]" type="file" class="form-control" id="product_image" accept="image/png, image/jpeg, image/jpg, image/svg, image/gif" multiple>
                            </div>

                            <div class="rounded-2 img-wrap">
                                <?php if(!empty($productImages)): ?>
                                    <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input class="form-control" name="oldDisplay_image" type="hidden" value="<?php echo e($image->image_path); ?>" />

                                        <div class="image-container" id="serviceImageRemove<?= $image['id'] ?>">
                                            <img class="editImg me-3" src="<?php echo e(asset($image->image_path)); ?>" alt="tutor image 1" />

                                            <a href="javascript:void(0);" class="serviceImageDelete"
                                                onclick="removeServiceImage(this.id)"
                                                id="serviceImageDelete<?= $image['id'] ?>"
                                                data-id="<?= $image['id'] ?>"
                                                data-src="<?= $image['image_path'] ?>"
                                                data-url="<?php echo e(URL::to('/')); ?>/product/image/delete"
                                                data-type="serviceImageRemove<?= $image['id'] ?>"
                                                data-name=""><i class="fa fa-trash deleteImage" aria-hidden="true"></i>
                                            </a>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="product_description">Product Description</label>
                            <textarea name="product_description" id="product_description" class="form-control" placeholder="Enter product description"><?php echo e($product->description); ?></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md p-4">
                                <small class="text-bold fw-medium d-block">Variations</small>
                                <div class="form-check mt-3">
                                    <input name="has_variants" class="form-check-input" name="has_variants" type="checkbox" id="has_variants" onchange="toggleVariantsSection(this)" <?php echo e($product->has_variant == 1 ? 'checked' : ''); ?>/>
                                    <label class="form-check-label" for="has_variants">
                                        This product has variants
                                    </label>
                                </div>
                            </div>
                            <div class="col-md p-4">
                                <small class="text-bold fw-medium d-block">Status</small>
                                <div class="form-check form-check-inline mt-3">
                                    <input class="form-check-input" type="radio" name="product_status" id="inlineRadio1" value="1" <?php echo e($product->status == 1 ? 'checked' : ''); ?> />
                                    <label class="form-check-label" for="inlineRadio1">Active</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="product_status" id="inlineRadio2" value="0" <?php echo e($product->status == 0 ? 'checked' : ''); ?> />
                                    <label class="form-check-label" for="inlineRadio2">Inactive</label>
                                </div>
                            </div>
                        </div>
                        <div id="variants-section" style="display: <?php echo e($product->has_variant == 1 ? 'block' : 'none'); ?>;">
                            <?php $__currentLoopData = $productVariant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row variant">
                                <div class="mb-3 col-lg-6 col-xl-6 col-12 mb-0">
                                    <label class="form-label" for="variant_name">Variant Name</label>
                                    <input type="text" name="variant_name[]" class="form-control" value="<?php echo e($variant->name); ?>" placeholder="Variant Name" />
                                </div>
                                <div class="mb-3 col-lg-6 col-xl-6 col-12 mb-0">
                                    <label class="form-label" for="variant_price">Variant Price</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text">£</span>
                                        <input type="text" name="variant_price[]" class="form-control" value="<?php echo e($variant->sale_price); ?>" placeholder="100" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" />
                                    </div>
                                </div>
                                <div class="mb-3 col-lg-12 col-xl-12 col-12 mb-0">
                                    <button type="button" class="btn btn-danger" onclick="removeVariant(this)">Remove Variant</button>
                                    
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3 col-lg-12 col-xl-12 col-12 mb-0">
                                <button type="button" class="btn btn-primary" onclick="addVariant()">Add Variant</button>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-primary" style="float: right;">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logFeller\resources\views/product-edit.blade.php ENDPATH**/ ?>