Hey<br /><br />Use the following OTP to complete your forgot password process complete. OTP is valid 5 Minutes<br />
<p>{{$otpSend}}</p> <br /><br />
Reach out to us if you have any support queries: <a href='http://127.0.0.1:8000/'>http://127.0.0.1:8000/</a><br />
<br /><br />Cheers,<br />Name<br />CyberX E-Commerce Team