Hey<br /><br />You had requested to account verify.<br />Please Click the <a href="{{$link}}"
    target="_blank">Confirm</a> to
account verification. <br /><br />
<br /><br />Cheers,<br />Name:The E-Commerce Team