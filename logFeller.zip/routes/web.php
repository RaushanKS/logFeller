<?php

use Carbon\Carbon;
use App\Models\User;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\DiscountController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/email-confirmation/{token}', function ($token) {
    $user = User::where('verification_token', '=', $token)
    ->first();
    if ($user) {
        if ($user->email_verified_at) {
            $message = 'Email verified already';
            return redirect()->route('login')
            ->with('success', 'Email verified already');
        } else {
            $user->email_verified_at = Carbon::now();
            $user->verification_token = null;
            $user->status = 1;
            $user->save();
            $message = 'Email verified';
            return redirect()->route('login')
            ->with('success', 'Email verified');
        }
    } else {
        $message = 'Something went wrong';
        return redirect()->route('login')
        ->with('success', 'Something went wrong');
    }
});



Route::get('/', [LoginController::class, 'index'])->name('login');
Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('admin.login');
Route::get('/forgot-password', [RegisterController::class, 'passwordForgot'])->name('admin.passwordForgot');
Route::post('/send-link', [RegisterController::class, 'sendLink'])->name('admin.sendLink');
Route::get('/password/reset/{token}', [RegisterController::class, 'passwordReset'])->name('admin.passwordReset');
Route::post('/password-reset', [RegisterController::class, 'passwordUpdate'])->name('admin.passwordUpdate');
Route::get('/register', [RegisterController::class, 'index'])->name('register');
Route::post('/register', [RegisterController::class, 'create'])->name('register.create');

Route::group(['middleware' => ['auth']], function () {
    Route::post('/logout', [DashboardController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'profile']);
    Route::post('/profile-info-update/{id}', [ProfileController::class, 'infoUpdate']);
    Route::post('/profile-image-update/{id}', [ProfileController::class, 'profileImageUpdate']);
    Route::post('/password-update/{id}', [ProfileController::class, 'passwordUpdate']);

    //Products
    Route::get('products', [ProductsController::class, 'index'])->name('products');
    Route::get('products/create', [ProductsController::class, 'create'])->name('products.create');
    Route::post('products/store', [ProductsController::class, 'store'])->name('products.store');
    Route::get('products/getProducts/', [ProductsController::class, 'getProducts']);
    Route::post('products/online-all/{status}', [ProductsController::class, 'onlineProductsAll'])->name('products.onlineProductsAll');
    Route::post('products/delete-all', [ProductsController::class, 'deleteProductsAll'])->name('products.deleteProductsAll');
    Route::get('product/delete/{id}', [ProductsController::class, 'destroy'])->name('product.delete');
    Route::get('product/edit/{id}', [ProductsController::class, 'edit'])->name('products.edit');
    Route::post('product/update/{id}', [ProductsController::class, 'update'])->name('product.update');
    Route::post('product/image/delete', [ProductsController::class, 'destroyImage'])->name('product.image.delete');

    //Discount coupon
    Route::get('coupons', [DiscountController::class, 'index'])->name('coupons');
    Route::get('coupon/create', [DiscountController::class, 'create'])->name('coupon.create');
    Route::post('coupon/store', [DiscountController::class, 'store'])->name('coupon.store');


    Route::get('discounts', [DiscountController::class, 'index'])->name('discounts');
    Route::get('discounts/create', [DiscountController::class, 'create'])->name('discounts.create');
    Route::get('discounts/getDiscounts/', [DiscountController::class, 'getDiscounts']);
    Route::post('discounts/online-all/{status}', [DiscountController::class, 'onlineDiscountsAll'])->name('discounts.onlineDiscountsAll');
    Route::post('discounts/delete-all', [DiscountController::class, 'deleteDiscountsAll'])->name('discounts.deleteDiscountsAll');
    Route::get('discounts/delete/{id}', [DiscountController::class, 'destroy'])->name('discounts.delete');
    
    Route::get('discounts/edit/{id}/{lang}', [DiscountController::class, 'edit'])->name('discounts.edit');
    Route::post('discounts/update/{id}', [DiscountController::class, 'update'])->name('discounts.update');
});
