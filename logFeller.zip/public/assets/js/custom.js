//Products
if ($("#productsTable").length > 0) {
    $("#productsTable").DataTable({
        dom: '<"card-header border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"user_status mt-50 width-200"><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
        buttons: [
            {
                className: "btn btn-danger me-2 DeleteALL",
                text: "Delete",
            },
            {
                className: "btn btn-success me-2 onlineAll",
                text: "Active",
            },
            {
                className: "btn btn-warning me-2 offlineAll",
                text: "InActive",
            },
            {
                extend: "collection",
                className: "btn btn-info dropdown-toggle me-2",
                text: "Export",
                buttons: [
                    {
                        extend: "print",
                        text: "Print",
                        className: "dropdown-item",
                        exportOptions: {
                            columns: [2, 3, 4],
                        },
                    },
                    {
                        extend: "csv",
                        text: "Csv",
                        className: "dropdown-item",
                        exportOptions: {
                            columns: [2, 3, 4],
                        },
                    },
                    {
                        extend: "excel",
                        text: "Excel",
                        className: "dropdown-item",
                        exportOptions: {
                            columns: [2, 3, 4],
                        },
                    },
                    {
                        extend: "pdf",
                        text: "Pdf",
                        className: "dropdown-item",
                        exportOptions: {
                            columns: [2, 3, 4],
                        },
                    },
                    {
                        extend: "copy",
                        text: "Copy",
                        className: "dropdown-item",
                        exportOptions: {
                            columns: [2, 3, 4],
                        },
                    },
                ],
                init: function (api, node, config) {
                    $(node).removeClass("btn-secondary");
                    $(node).parent().removeClass("btn-group");
                    setTimeout(function () {
                        $(node)
                            .closest(".dt-buttons")
                            .removeClass("btn-group")
                            .addClass("d-inline-flex");
                    }, 50);
                },
            },
        ],
        initComplete: function () {
            this.api()
                .columns(4)
                .every(function () {
                    var column = this;
                    var select = $(
                        '<select id="orderStatus" class="form-select text-capitalize"><option value=""> Select Status </option><option value="1">Active</option><option value="0">Incative</option></select>'
                    )
                        .appendTo(".user_status")
                        .on("change", function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                            column
                                .search(val ? "" + val + "" : "", true, false)
                                .draw();
                        });
                });
        },
        retrieve: true,
        paging: true,
        processing: true,
        serverSide: true,
        ajax: baseUrl + "/products/getProducts",
        pageLength: 10,
        language: {
            searchPlaceholder: "Search By Product Name",
        },
        columns: [
            {
                data: "id",
            },
            {
                data: "image",
            },
            {
                data: "name",
            },
            {
                data: "price",
            },
            {
                data: "description",
            },
            {
                data: "status",
            },
        ],
        aoColumnDefs: [
            {
                targets: 0,
                orderable: false,
                checkboxes: {
                    selectRow: true,
                },
            },

            {
                aTargets: [1],
                mData: "id",
                mRender: function (data, type, row, meta) {
                    if (row.image !== undefined && row.image !== null) {
                        return (
                            '<img class="round" src="' +
                            baseUrl +
                            "/" +
                            row.image +
                            '" alt="' +
                            row.name +
                            '" width="40px" height="40px" />'
                        );
                    } else {
                        return (
                            '<img class="round" src="' +
                            baseUrl +
                            '/assets/img/placeholder.png" alt="' +
                            row.name +
                            '" width="40px" height="40px" />'
                        );
                    }
                },
            },
            {
                aTargets: [2],
                mData: "id",
                mRender: function (data, type, row, meta) {
                    if (row.parent_id !== 0) {
                        return "<p class='childNode'>" + row.name + "</p>";
                    } else {
                        return "<p>" + row.name + "</p>";
                    }
                },
            },
            {
                targets: 6,
                orderable: false,
            },
            {
                aTargets: [5],
                mData: "id",
                mRender: function (data, type, row, meta) {
                    if (row.status == 1) {
                        return '<span class="badge bg-success bg-glow">Acive</span>';
                    } else {
                        return '<span class="badge bg-danger bg-glow">In-Active</span>';
                    }
                },
            },
            {
                aTargets: [6],
                mData: "id",
                mRender: function (data, type, row, meta) {
                    let editUrl = baseUrl + "/product/edit/" + row.id;
                    let viewUrl = baseUrl + "/product/view/" + row.id;
                    let deleteUrl = baseUrl + "/product/delete/" + row.id;
                    // <a class="action-class view-access editIcon" href="' +viewUrl +'" id="view_' +row.id +'"  ><i class="far fa-eye" aria-hidden="true"></i></a>
                    return (
                        '<a class="action-class view-access editIcon me-2" href="' +
                        editUrl +
                        '" id="edit_' +
                        row.id +
                        '"  ><i class="far fa-edit" aria-hidden="true"></i></a><a class="delete-record action-class deleteIcon" href="javascript:void(0)" data-url="' +
                        deleteUrl +
                        '" onclick="confirmation(this);"  data-type="product" id="delete_record_' +
                        row.id +
                        '"><i class="fa fa-trash" aria-hidden="true"></i></a>'
                    );
                },
            },
        ],
        select: {
            style: "multi",
        },
        order: [[2, "asc"]],
    });

    $(".onlineAll").on("click", function (e) {
        let dt_user_table = $("#productsTable").DataTable();
        console.log(dt_user_table);
        var rows_selected = dt_user_table.column(0).checkboxes.selected();
        if (rows_selected.length < 1) {
            let html =
                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">Please select at least one</div></div>';
            $(".messageShowAlert").append(html);
            setTimeout(function () {
                $(".toast-autohide").remove();
            }, 3000);
            return false;
        }
        rows_selected = rows_selected.join(",");
        rows_selected = rows_selected.split(",");
        Swal.fire({
            title: "Are you sure ?",
            text: "You want to active",
            icon: "warning",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            // cancelButtonText: "No",
            confirmButtonText: "Yes",
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: baseUrl + "/products/online-all/1",
                    data: {
                        _token: $('meta[name="csrf-token"]').attr("content"),
                        ids: rows_selected,
                    },
                    success: function (response) {
                        if (response.success == true) {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #288900;color: #f1f1f1;"><strong class="me-auto">Success</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                                document.location.reload();
                            }, 3000);
                        } else {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                                document.location.reload();
                            }, 3000);
                        }
                    },
                });
            }
        });
    });

    $(".offlineAll").on("click", function (e) {
        let dt_user_table = $("#productsTable").DataTable();
        var rows_selected = dt_user_table.column(0).checkboxes.selected();
        if (rows_selected.length < 1) {
            let html =
                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">Please select at least one</div></div>';
            $(".messageShowAlert").append(html);
            setTimeout(function () {
                $(".toast-autohide").remove();
            }, 3000);
            return false;
        }
        rows_selected = rows_selected.join(",");
        rows_selected = rows_selected.split(",");
        Swal.fire({
            title: "Are you sure ?",
            text: "You want to inactive",
            icon: "warning",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            // cancelButtonText: "No",
            confirmButtonText: "Yes",
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: baseUrl + "/products/online-all/0",
                    data: {
                        _token: $('meta[name="csrf-token"]').attr("content"),
                        ids: rows_selected,
                    },
                    success: function (response) {
                        if (response.success == true) {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #288900;color: #f1f1f1;"><strong class="me-auto">Success</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                            }, 3000);
                            $(location).attr("href", window.location);
                        } else {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                            }, 3000);
                            $(location).attr("href", window.location);
                        }
                    },
                });
            }
        });
    });

    $(".DeleteALL").on("click", function (e) {
        let dt_user_table = $("#productsTable").DataTable();
        var rows_selected = dt_user_table.column(0).checkboxes.selected();
        console.log(rows_selected.length);
        if (rows_selected.length < 1) {
            let html =
                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">Please select at least one</div></div>';
            $(".messageShowAlert").append(html);
            setTimeout(function () {
                $(".toast-autohide").remove();
            }, 3000);
            return false;
        }
        rows_selected = rows_selected.join(",");
        rows_selected = rows_selected.split(",");
        Swal.fire({
            title: "Are you sure ?",
            text: "You want to delete",
            icon: "warning",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            // cancelButtonText: "No",
            confirmButtonText: "Yes",
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: baseUrl + "/products/delete-all",
                    data: {
                        _token: $('meta[name="csrf-token"]').attr("content"),
                        ids: rows_selected,
                    },
                    success: function (response) {
                        if (response.success == true) {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #288900;color: #f1f1f1;"><strong class="me-auto">Success</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                            }, 3000);
                            $(location).attr("href", window.location);
                        } else {
                            let html =
                                '<div class="toast toast-autohide show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false"><div class="toast-header" style="background: #ff0000;color: #fafbfd;"><strong class="me-auto">Danger!</strong><small class="text-muted" style="color:#ffffff!important">just now</small><button type="button" class="ms-1 btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">' +
                                response.message +
                                "</div></div>";
                            $(".messageShowAlert").append(html);
                            setTimeout(function () {
                                $(".toast-autohide").remove();
                            }, 3000);
                            $(location).attr("href", window.location);
                        }
                    },
                });
            }
        });
    });
}


function confirmation(e) {
    let id = $(e).attr("id");
    let urlRequest = $("#" + id).data("url");
    let deleteType = $("#" + id).data("type");
    Swal.fire({
        title: "Are you sure ?",
        text: "You want to delete this " + deleteType + ".",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        // cancelButtonText: "No",
        confirmButtonText: "Yes",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "GET",
                url: urlRequest,
                success: function (response) {
                    if (response.success == true) {
                        $("#" + id)
                            .closest("tr")
                            .remove();
                        console.log(window.location);
                        $(location).attr("href", window.location);
                    } else {
                        $(location).attr("href", window.location);
                    }
                },
            });
        }
    });
}

//delete product image
function removeServiceImage(id) {
    let imagePath = $("#" + id).data("src");
    let imageIndex = $("#" + id).data("id"); 
    let urlRequest = $("#" + id).data("url");
    let divId = $("#" + id).data("type");

    Swal.fire({
        title: "Are you sure?",
        text: "Do you want to delete this image?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        // cancelButtonText: "No",
        confirmButtonText: "Yes",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                id: imageIndex,
                url: urlRequest,
                data: {
                    _token: $('meta[name="csrf-token"]').attr("content"),
                    id: imageIndex,
                    imagePath: imagePath,
                },
                success: function (response) {
                    if (response.status == "success") {
                        $("#" + divId).remove();
                        $(location).attr("href", window.location);
                    } else {
                        $(location).attr("href", window.location);
                    }
                },
            });
        }
    });
}

function discountType(id) {
    let discountType = $("#" + id).val();
    // console.log(discountType);
    if (discountType == "fixed") {
        $("#fixedDiscount").show();
        $("#discount_percent").val("");
        $("#percentageDiscount").hide();
    } else {
        $("#fixedDiscount").hide();
        $("#discount_amount").val("");
        $("#percentageDiscount").show();
    }
}