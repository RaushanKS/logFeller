<?php

namespace App\Http\Controllers\Api;

use Exception;
use App\Models\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ProductImage;
use App\Models\ProductVariant;

class ProductController extends Controller
{
    public function fetchProducts(Request $request)
    {
        try {
            $inputs = $request->all();
            $productArr = [];

            $totalProducts = Products::where('status', 1)
                ->whereNull('deleted_at')
                ->count();

            // Fetch products with images and variants
            $products = Products::where('status', 1)
                ->whereNull('deleted_at')
                ->with(['images', 'variants'])
                ->take(10)
                ->get(['id', 'name', 'slug', 'description', 'sale_price', 'has_variant']);

            foreach ($products as $product) {
                $wishlist = 'no';
                // Uncomment and modify the below code if you have a wishlist functionality
                // if (isset($inputs['uid']) && !empty($inputs['uid'])) {
                //     $wishlistExist = Wishlist::where('product_id', $product->id)->where('user_id', $inputs['uid'])->first();
                //     if ($wishlistExist) {
                //         $wishlist = 'yes';
                //     }
                // }

                $productData = [
                    "id" => $product->id,
                    "name" => $product->name,
                    "slug" => $product->slug,
                    "description" => $product->description,
                    "featured_image" => $product->featured_image ? asset($product->featured_image) : '',
                    "wishlist" => $wishlist,
                    "images" => $product->images->map(function ($image) {
                        return asset($image->image_path);
                    }),
                    "variants" => $product->has_variant ? $product->variants : []
                ];

                $productArr[] = $productData;
            }

            return response()->json(['status' => 'success', 'message' => 'Record Found','totalProducts' => $totalProducts, 'data' => ['homeProduct' => $productArr]], 200);
        } catch (Exception $e) {
            return response()->json(['status' => 'failed', 'message' => $e->getMessage()], 500);
        }
    }

}
