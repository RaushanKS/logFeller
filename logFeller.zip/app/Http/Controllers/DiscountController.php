<?php

namespace App\Http\Controllers;

use App\Models\Discount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class DiscountController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // $totalRecords = Products::count();
        // $activated = Products::where('status', 1)->count();
        // $inactivated = Products::where('status', 0)->count();
        // $twoDaysAgo = Carbon::now()->subDays(30);

        // $recentProducts = Products::where('created_at', '>=', $twoDaysAgo)->count();

        // return view('products-list', compact(['totalRecords', 'activated', 'inactivated', 'recentProducts']));
        return view('discount-coupon');
    }

    public function create(Request $request)
    {
        return view('discount-coupon');
    }

    public function store(Request $request)
    {
        $input = $request->all();

        $rules = [
            'coupon_title' => 'required',
            'discount_type' => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
        ];

        $customMessages = [
            'required' => 'The :attribute field is required.',
        ];
        $validator = Validator::make($request->all(), $rules, $customMessages);
        if ($validator->fails()) {
            Session::flash('error', __($validator->errors()->first()));
            return redirect()->back()->with('error', $validator->errors()->first());
        }

        $discounts = Discount::create([
            'name' => $input['coupon_title'],
            'discount_type' => $input['discount_type'],
            'discount_amount' => $input['discount_amount'],
            'discount_percent' => $input['discount_percent'],
            'max_discount' => $input['max_discount'],
            'min_order_amount' => $input['min_order_amount'],
            'description' => $input['coupon_description'],
            'start_date' => $input['start_date'],
            'end_date' => $input['end_date'],
            'status' => ($input['coupon_status']) ? $input['coupon_status'] : 0,
        ]);
        if ($discounts) {
            return redirect()->back()->with('success', 'Discount coupon created successfully');
        } else {
            return redirect()->back()->with('error', 'something went wrong please try again!');
        }
    }

}
